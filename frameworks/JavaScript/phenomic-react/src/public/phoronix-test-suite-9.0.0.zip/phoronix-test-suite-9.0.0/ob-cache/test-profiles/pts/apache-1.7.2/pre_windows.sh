#!/bin/sh
cd Apache24/bin
./httpd.exe &
sleep 10
