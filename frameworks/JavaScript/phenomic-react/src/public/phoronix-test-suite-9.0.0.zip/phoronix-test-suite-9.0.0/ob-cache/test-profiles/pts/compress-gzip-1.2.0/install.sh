#!/bin/sh

echo "#!/bin/sh
tar -zcf to-compress.tar.gz to-compress" > compress-gzip
chmod +x compress-gzip 


