#!/bin/sh
tar -xjf ImageMagick-6.9.0-0.tar.bz2
cd ImageMagick-6.9.0-0/
./configure > /dev/null
make clean
