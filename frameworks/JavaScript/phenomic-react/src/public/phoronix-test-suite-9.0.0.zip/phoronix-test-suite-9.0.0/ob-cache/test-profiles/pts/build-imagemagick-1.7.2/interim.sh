#!/bin/sh
cd ImageMagick-6.9.0-0/
make clean
