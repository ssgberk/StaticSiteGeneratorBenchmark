#!/bin/sh
rm -f $HOME/*.tga
