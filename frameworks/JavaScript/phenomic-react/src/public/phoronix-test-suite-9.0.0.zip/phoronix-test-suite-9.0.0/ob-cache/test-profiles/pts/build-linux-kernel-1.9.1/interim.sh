#!/bin/sh

cd linux-4.18/
make clean
