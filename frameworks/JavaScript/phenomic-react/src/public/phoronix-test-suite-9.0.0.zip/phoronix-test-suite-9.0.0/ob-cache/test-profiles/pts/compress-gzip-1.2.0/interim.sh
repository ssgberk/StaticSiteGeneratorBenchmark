#!/bin/sh

rm -f to-compress.tar.gz
